1. 我们租的服务器已经部署好了,您并不需要启动服务器
2. 如果您想使用自己的服务器，您需要安装node, mongodb
3. 并且在internet.cs中修改reqUri为您的IP，默认端口为8000
4. node bin/www启动服务器